#window
FPS = 15
WINDOW_SIZE = (640, 480)

#folders ('cards_mailru' or 'cards_classic')
CARDS_FOLDER = 'cards_mailru'

#colors
TABLE_COLOR = (0x23, 0x1F, 0x20)
SHADOW_ALPHA = 0x17